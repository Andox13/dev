import {ServiceClient } from './server'

export const serviceClient = new ServiceClient().getInstance()