export interface FileType {
  id: number;
  url: string;
}